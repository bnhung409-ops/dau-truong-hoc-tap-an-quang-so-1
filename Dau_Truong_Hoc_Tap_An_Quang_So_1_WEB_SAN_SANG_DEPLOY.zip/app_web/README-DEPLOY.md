# Đấu Trường Học Tập An Quang Số 1

Bản web sẵn để triển khai trên hosting tĩnh.

Lưu ý: bản hiện tại lưu dữ liệu bằng localStorage trên từng thiết bị. Để giáo viên và học sinh dùng chung dữ liệu/mã lớp/mã đề giữa nhiều điện thoại, cần kết nối cơ sở dữ liệu/backend dùng chung.


/* ===================== NGÂN HÀNG CÂU HỎI THEO MÔN ===================== */
const questionBank={
  math:[
    {q:"Số nào lớn hơn 7?",a:["5","6","8","4"],correct:2,diff:20},
    {q:"3 + 4 bằng bao nhiêu?",a:["6","7","8","9"],correct:1,diff:20},
    {q:"10 - 6 bằng bao nhiêu?",a:["3","4","5","6"],correct:1,diff:20},
    {q:"Số nào là số chẵn?",a:["7","9","12","15"],correct:2,diff:20},
    {q:"5 × 2 bằng bao nhiêu?",a:["7","8","10","12"],correct:2,diff:20},
    {q:"15 lớn hơn 9 bao nhiêu đơn vị?",a:["5","6","7","8"],correct:1,diff:20},
    {q:"Hình có 3 cạnh là hình gì?",a:["Hình vuông","Hình tròn","Hình tam giác","Hình chữ nhật"],correct:2,diff:20},
    {q:"20 : 4 bằng bao nhiêu?",a:["4","5","6","8"],correct:1,diff:20},
    {q:"Số liền sau 19 là số nào?",a:["18","19","20","21"],correct:2,diff:20},
    {q:"2 + 5 + 3 bằng bao nhiêu?",a:["8","9","10","11"],correct:2,diff:20},
    {q:"Một tuần có bao nhiêu ngày?",a:["5","6","7","8"],correct:2,diff:20},
    {q:"Số nào bé nhất?",a:["14","9","12","16"],correct:1,diff:20}
  ],
  vietnamese:[
    {q:"Từ nào chỉ con vật?",a:["cây","mèo","bàn","đẹp"],correct:1,diff:20},
    {q:"Từ nào là từ chỉ hoạt động?",a:["chạy","bút","xanh","bàn"],correct:0,diff:20},
    {q:"Từ trái nghĩa với ‘cao’ là gì?",a:["dài","thấp","rộng","to"],correct:1,diff:20},
    {q:"Câu nào là câu hỏi?",a:["Em đi học.","Bạn tên là gì?","Trời rất đẹp.","Em thích đọc sách."],correct:1,diff:20},
    {q:"Từ nào viết đúng chính tả?",a:["xinh đẹp","sinh đep","xinh đệp","sinh đẹp"],correct:0,diff:20},
    {q:"Từ ‘chăm chỉ’ nói về điều gì?",a:["Màu sắc","Phẩm chất","Đồ vật","Con vật"],correct:1,diff:20},
    {q:"Trong câu ‘Bé Lan đọc sách’, ai đọc sách?",a:["Sách","Bé Lan","Cô giáo","Mẹ"],correct:1,diff:20},
    {q:"Từ nào đồng nghĩa gần nhất với ‘vui’?",a:["buồn","mừng","giận","mệt"],correct:1,diff:20},
    {q:"Dấu câu nào thường dùng cuối câu hỏi?",a:[".","!","?",","] ,correct:2,diff:20},
    {q:"Từ nào chỉ đặc điểm?",a:["đỏ","chạy","bút","học"],correct:0,diff:20},
    {q:"Từ nào là tên một đồ vật?",a:["cây","bàn","nhanh","đẹp"],correct:1,diff:20},
    {q:"Câu ‘Em rất yêu trường em.’ thể hiện điều gì?",a:["Tình cảm","Thời gian","Địa điểm","Số lượng"],correct:0,diff:20}
  ],
  science:[
    {q:"Cây xanh cần gì để phát triển?",a:["Ánh sáng và nước","Chỉ có đá","Chỉ có cát","Không cần gì"],correct:0,diff:20},
    {q:"Con vật nào sống dưới nước?",a:["Cá","Gà","Mèo","Chó"],correct:0,diff:20},
    {q:"Bộ phận nào giúp chúng ta nhìn?",a:["Tai","Mắt","Mũi","Tay"],correct:1,diff:20},
    {q:"Nước đá là thể gì của nước?",a:["Rắn","Lỏng","Khí","Không xác định"],correct:0,diff:20},
    {q:"Mặt Trời cung cấp cho Trái Đất chủ yếu gì?",a:["Ánh sáng và nhiệt","Muối","Đá","Cát"],correct:0,diff:20},
    {q:"Con người hít vào khí gì để thở?",a:["Oxi","Khói","Hơi nước","Khí cacbonic"],correct:0,diff:20},
    {q:"Bộ phận nào giúp cây hút nước từ đất?",a:["Rễ","Hoa","Quả","Lá"],correct:0,diff:20},
    {q:"Âm thanh truyền đến tai giúp ta làm gì?",a:["Nghe","Nhìn","Nếm","Ngửi"],correct:0,diff:20},
    {q:"Mưa là nước ở đâu rơi xuống?",a:["Mây","Đất","Biển","Cây"],correct:0,diff:20},
    {q:"Loài nào là động vật có vú?",a:["Cá","Mèo","Gà","Ếch"],correct:1,diff:20},
    {q:"Nguồn năng lượng nào có từ Mặt Trời?",a:["Năng lượng mặt trời","Đá","Đất","Muối"],correct:0,diff:20},
    {q:"Bộ phận nào giúp cá bơi?",a:["Vây","Lông","Cánh","Chân"],correct:0,diff:20}
  ],
  english:[
    {q:"What color is the sky on a clear day?",a:["Blue","Black","Green","Pink"],correct:0,diff:20},
    {q:"What is ‘con mèo’ in English?",a:["Dog","Cat","Bird","Fish"],correct:1,diff:20},
    {q:"Choose the correct word: I ___ a student.",a:["am","is","are","be"],correct:0,diff:20},
    {q:"What number is ‘five’?",a:["3","4","5","6"],correct:2,diff:20},
    {q:"What is the opposite of ‘big’?",a:["small","long","hot","fast"],correct:0,diff:20},
    {q:"‘Hello’ means what in Vietnamese?",a:["Tạm biệt","Xin chào","Cảm ơn","Xin lỗi"],correct:1,diff:20},
    {q:"Which one is a fruit?",a:["Apple","Table","Chair","Book"],correct:0,diff:20},
    {q:"Complete: This is ___ book.",a:["a","an","are","am"],correct:0,diff:20},
    {q:"How many days are there in a week?",a:["Five","Six","Seven","Eight"],correct:2,diff:20},
    {q:"Which word means ‘màu đỏ’?",a:["Blue","Red","Green","White"],correct:1,diff:20},
    {q:"Choose the animal: ___ is a dog.",a:["Dog","Desk","Door","Doll"],correct:0,diff:20},
    {q:"What is ‘book’ in Vietnamese?",a:["Bút","Sách","Bàn","Ghế"],correct:1,diff:20}
  ],
  challenge:[
    {q:"Có 5 quả táo, cho đi 2 quả. Còn lại mấy quả?",a:["2","3","4","5"],correct:1,diff:30},
    {q:"Nếu hôm nay là thứ Hai thì ngày mai là thứ mấy?",a:["Chủ nhật","Thứ Hai","Thứ Ba","Thứ Tư"],correct:2,diff:30},
    {q:"Con gì sáng sớm thường gáy ‘ò ó o’?",a:["Con mèo","Con gà trống","Con cá","Con bò"],correct:1,diff:30},
    {q:"Một năm có bao nhiêu tháng?",a:["10","11","12","13"],correct:2,diff:30},
    {q:"Hình nào không có góc?",a:["Hình vuông","Hình tam giác","Hình tròn","Hình chữ nhật"],correct:2,diff:30},
    {q:"Từ tiếng Anh ‘sun’ nghĩa là gì?",a:["Mặt trăng","Mặt trời","Ngôi sao","Mây"],correct:1,diff:30},
    {q:"Con người dùng bộ phận nào để nghe?",a:["Mắt","Tai","Mũi","Miệng"],correct:1,diff:30},
    {q:"Nếu có 10 viên bi và cho bạn 3 viên, còn lại bao nhiêu?",a:["6","7","8","9"],correct:1,diff:30},
    {q:"Từ nào là tên một môn học?",a:["Toán","Cái bàn","Con mèo","Cây xanh"],correct:0,diff:30},
    {q:"Nước sôi thường có nhiệt độ khoảng bao nhiêu ở điều kiện thường?",a:["0°C","50°C","100°C","200°C"],correct:2,diff:30},
    {q:"‘Thank you’ nghĩa là gì?",a:["Xin chào","Cảm ơn","Tạm biệt","Xin lỗi"],correct:1,diff:30},
    {q:"Số nào vừa là số chẵn vừa lớn hơn 10?",a:["9","11","12","13"],correct:2,diff:30}
  ]
};
const parts=[
  {key:'math',name:'🔢 Toán',label:'Toán',time:20},
  {key:'vietnamese',name:'📖 Tiếng Việt',label:'Tiếng Việt',time:20},
  {key:'mixed',name:'🧠 Tổng hợp',label:'Khoa học • Tiếng Anh • Kiến thức chung',time:20},
  {key:'challenge',name:'⚡ Đua sức',label:'Thử thách liên môn',time:30}
];

/* Mỗi tài khoản có seed riêng => thứ tự/bộ câu khác nhau.
   Với các tài khoản hiện có, 5 câu đầu của cùng môn được lấy từ các vị trí khác nhau,
   nên Minh và Phương Anh không làm trùng câu trong cùng chặng. */
function hashCode(str){let h=2166136261;for(let i=0;i<str.length;i++){h^=str.charCodeAt(i);h=Math.imul(h,16777619)}return h>>>0;}
function seededShuffle(arr,seed){let a=arr.slice(),s=seed>>>0;for(let i=a.length-1;i>0;i--){s=(Math.imul(s,1664525)+1013904223)>>>0;let j=s%(i+1);[a[i],a[j]]=[a[j],a[i]]}return a;}
function getMixedBank(){const sci=(db.customBanks?.science?.length?db.customBanks.science:questionBank.science);const eng=(db.customBanks?.english?.length?db.customBanks.english:questionBank.english);return sci.map(q=>({...q,subject:'Khoa học'})).concat(eng.map(q=>({...q,subject:'Tiếng Anh'})));}
function buildQuestions(username,stage,partIndex){
  const part=parts[partIndex];
  let bank=part.key==='mixed'?getMixedBank():(db.customBanks && db.customBanks[part.key] && db.customBanks[part.key].length ? db.customBanks[part.key] : questionBank[part.key]);
  const seed=hashCode(username+'|'+stage+'|'+part.key);
  const shuffled=seededShuffle(bank,seed);
  const studentKeys=Object.keys(students).sort();
  const studentIndex=Math.max(0,studentKeys.indexOf(username));
  // Chia các cửa sổ câu hỏi khác nhau cho từng tài khoản. Với 2 học sinh hiện tại,
  // cùng một chặng/môn sẽ không lấy trùng bộ 5 câu; sang chặng khác lại đổi bộ.
  const blockSize=5;
  const offset=((Math.max(0,stage-1)*blockSize)+(studentIndex*blockSize))%Math.max(1,shuffled.length);
  const rotated=shuffled.slice(offset).concat(shuffled.slice(0,offset));
  return rotated.slice(0,5).map(q=>({...q,subject:q.subject||part.label}));
}

/* ===================== PHẦN ĐIỀU KHIỂN BẢN MỚI ===================== */
const DB_KEY = 'DAU_TRUONG_AN_QUANG_SO_1_DB_V3';
const seedStudents = {
  "do.nhat.minh":{name:"Đỗ Nhật Minh",pass:"Minh123",class:"1A1",score:0,stage:0,completed:{}},
  "do.phuong.anh":{name:"Đỗ Phương Anh",pass:"Anh123",class:"1A1",score:0,stage:0,completed:{}}
};
const seedTeachers = {
  "do.nhat.nam":{name:"Đỗ Nhật Nam",pass:"Nam123"},
  "do.thuy.duong":{name:"Đỗ Thùy Dương",pass:"Duong123"},
  "do.thao.nguyen":{name:"Đỗ Thảo Nguyên",pass:"Nguyen123"}
};
const defaultSettings={appName:'ĐẤU TRƯỜNG HỌC TẬP AN QUANG SỐ 1',schoolName:'TRƯỜNG TIỂU HỌC AN QUANG SỐ 1',tagline:'Phiên bản chính thức • Học tập • Thi đấu • Tỏa sáng',logo:'logo-an-quang-so-1.png'};
function makeCode(prefix='AQ'){return prefix+Math.random().toString(36).slice(2,7).toUpperCase();}
function getDB(){
  try{
    const raw=localStorage.getItem(DB_KEY);
    if(raw){
      const x=JSON.parse(raw);
      x.students=x.students||JSON.parse(JSON.stringify(seedStudents));
      x.teachers=x.teachers||JSON.parse(JSON.stringify(seedTeachers));
      x.events=x.events||[]; x.customBanks=x.customBanks||{}; x.onlineClasses=x.onlineClasses||[]; x.onlineExams=x.onlineExams||[]; x.settings={...defaultSettings,...(x.settings||{})};
      Object.values(x.students).forEach(st=>{st.completed=st.completed||{};st.score=Number(st.score)||0;st.stage=Number(st.stage)||0;st.class=st.class||'1A1';st.schoolExamScore=Number(st.schoolExamScore)||0;st.onlineExamScore=Number(st.onlineExamScore)||0;st.standardScore=(st.schoolExamScore+st.onlineExamScore)/2;st.examResults=st.examResults||{};});
      return x;
    }
  }catch(e){}
  const x={students:JSON.parse(JSON.stringify(seedStudents)),teachers:JSON.parse(JSON.stringify(seedTeachers)),events:[],onlineClasses:[],onlineExams:[],customBanks:{},settings:{...defaultSettings},updatedAt:new Date().toISOString()};
  localStorage.setItem(DB_KEY,JSON.stringify(x)); return x;
}
function saveDB(){db.updatedAt=new Date().toISOString();localStorage.setItem(DB_KEY,JSON.stringify(db));}
let db=getDB(), students=db.students, teachers=db.teachers;
let role='student', current=null, currentUsername=null, currentStage=1, currentPart=0, qIndex=0, timerInt=null, seconds=20, currentQuestions=[];

function applySettings(){
  const s=db.settings||defaultSettings;
  document.querySelectorAll('.appName').forEach(e=>e.textContent=s.appName);
  document.querySelectorAll('.schoolName').forEach(e=>e.textContent=s.schoolName);
  document.querySelectorAll('.appTagline').forEach(e=>e.textContent=s.tagline);
  document.querySelectorAll('.appLogo').forEach(e=>e.src=s.logo||'logo-an-quang-so-1.png');
  document.title=s.appName+' • '+s.schoolName;
}
function show(id){
  document.querySelectorAll('main>section').forEach(s=>s.classList.add('hidden'));
  const target=document.getElementById(id); if(!target)return;
  target.classList.remove('hidden');
  if(id==='ranking')renderRanking('class');
  if(id==='events')renderAllEvents();
  if(id==='home')renderHomeEvents();
  if(id==='teacher'&&current?.role==='teacher')renderTeacher();
  if(id==='events' && current?.role==='teacher')renderTeacherEventsPage();
  if(id==='student'&&current?.role==='student'){renderOnlineClasses();renderStudentExamResult();}
  if(id==='teacher'&&current?.role==='teacher'){renderOnlineClassesTeacher();renderOnlineExamsTeacher();renderStandardScores();}
  window.scrollTo(0,0);
  document.documentElement.scrollTop=0;
  document.body.scrollTop=0;
}
function setRole(r){role=r;document.getElementById('studentTab').classList.toggle('active',r==='student');document.getElementById('teacherTab').classList.toggle('active',r==='teacher');document.getElementById('classBox').style.display=r==='student'?'block':'none';}
function login(){
  const u=document.getElementById('user').value.trim(),p=document.getElementById('pass').value;
  if(role==='student'&&students[u]&&students[u].pass===p){currentUsername=u;current=students[u];current.role='student';loadStudent();}
  else if(role==='teacher'&&teachers[u]&&teachers[u].pass===p){currentUsername=u;current=teachers[u];current.role='teacher';renderTeacher();show('teacher');}
  else document.getElementById('loginMsg').innerHTML='<span style="color:#d44">Sai tài khoản hoặc mật khẩu.</span>';
}
function loadStudent(){
  document.getElementById('welcome').textContent='Xin chào, '+current.name+'! 👋';
  document.getElementById('score').textContent=current.score;document.getElementById('standardScore').textContent=Number(((Number(current.schoolExamScore)||0)+(Number(current.onlineExamScore)||0))/2).toFixed(1);document.getElementById('stageProgress').textContent=current.stage+'/50 chặng';document.getElementById('bar').style.width=(current.stage/50*100)+'%';
  const titles=['Đồng','Bạc','Vàng','Bạch Kim','Kim Cương','Huyền Thoại','Cao Thủ','Thách Đấu'],ti=Math.min(7,Math.floor(current.score/500));
  document.getElementById('title').textContent=titles[ti];document.getElementById('rankBadge').textContent=['🥉 ','🥈 ','🥇 ','💎 ','💠 ','🌟 ','🔥 ','⚔️ '][ti]+titles[ti];
  const c=document.getElementById('chains');c.innerHTML='';
  for(let i=1;i<=50;i++){let d=document.createElement('div');d.className='stage '+(i<=current.stage?'done':i===current.stage+1?'open':'lock');d.innerHTML=(i<=current.stage?'✓ ':'')+'Chặng '+i;d.onclick=()=>{if(i===current.stage+1)startStage(i);else if(i<=current.stage)alert('Chặng này đã hoàn thành.');else alert('Hãy hoàn thành các chặng trước.');};c.appendChild(d);}
  renderStudentEvents();show('student');
}
function startStage(n){currentStage=n;currentPart=0;qIndex=0;currentQuestions=buildQuestions(currentUsername,currentStage,currentPart);show('stage');nextQuestion();}
function nextQuestion(){
  if(qIndex>=currentQuestions.length){qIndex=0;currentPart++;if(currentPart>=parts.length){current.stage=Math.max(current.stage,currentStage);current.score+=50;current.completed['stage_'+currentStage]={completedAt:new Date().toISOString(),parts:parts.map(p=>p.key)};saveDB();clearInterval(timerInt);alert('🎉 Hoàn thành Chặng '+currentStage+'! Cộng 50 điểm.');loadStudent();return;}currentQuestions=buildQuestions(currentUsername,currentStage,currentPart);}
  const q=currentQuestions[qIndex],part=parts[currentPart];
  document.getElementById('stageName').textContent='Chặng '+currentStage+' • '+part.name+' • Câu '+(qIndex+1)+'/'+currentQuestions.length;
  document.getElementById('subjectName').textContent=q.subject?part.name+' — '+q.subject:part.name;document.getElementById('question').textContent=q.q;
  const a=document.getElementById('answers');a.innerHTML='';const feedback=document.getElementById('answerFeedback');if(feedback)feedback.innerHTML='';
  q.a.forEach((x,i)=>{let b=document.createElement('button');b.textContent=String.fromCharCode(65+i)+'. '+x;b.onclick=()=>answer(i===q.correct,i,q);a.appendChild(b);});
  seconds=Number(q.diff??part.time);document.getElementById('timer').textContent=seconds+' giây';clearInterval(timerInt);timerInt=setInterval(()=>{seconds--;document.getElementById('timer').textContent=seconds+' giây';if(seconds<=0){clearInterval(timerInt);answer(false,-1,q,true);}},1000);
}
function answer(correct,chosenIndex=-1,q=currentQuestions[qIndex],timeout=false){
  clearInterval(timerInt);document.querySelectorAll('#answers button').forEach((b,i)=>{b.disabled=true;if(i===q.correct)b.classList.add('correct-answer');if(i===chosenIndex&&i!==q.correct)b.classList.add('wrong-answer');});
  if(correct){const earned=Number(q.points??10);current.score+=earned;saveDB();document.getElementById('score').textContent=current.score;}
  const feedback=document.getElementById('answerFeedback');
  if(feedback){const right='Đáp án đúng: '+String.fromCharCode(65+q.correct)+'. '+q.a[q.correct];feedback.className='answer-feedback '+(correct?'ok':'bad');feedback.innerHTML=(timeout?'⏰ Hết giờ. ':'')+(correct?'✅ Chính xác! +'+Number(q.points??10)+' điểm.':'❌ Chưa đúng. ')+right;}
  qIndex++;setTimeout(nextQuestion,1400);
}
function getRankRows(){return Object.entries(students).map(([u,s])=>({u,...s})).sort((a,b)=>b.score-a.score||b.stage-a.stage||a.name.localeCompare(b.name,'vi'));}
function renderRanking(type){
  let rows=getRankRows();if(type==='class'&&current?.role==='student')rows=rows.filter(r=>r.class===current.class);if(type==='grade'&&current?.role==='student'){const g=current.class.match(/^\d+/)?.[0];rows=rows.filter(r=>r.class.match(/^\d+/)?.[0]===g);}if(!rows.length)rows=getRankRows();
  const title=type==='class'?'Theo lớp':type==='grade'?'Theo khối':'Toàn trường';document.getElementById('rankTable').innerHTML='<h3>'+title+'</h3><table><tr><th>Hạng</th><th>Học sinh</th><th>Lớp</th><th>Điểm</th><th>Chặng</th></tr>'+rows.map((r,i)=>`<tr><td>${i+1}</td><td>${esc(r.name)}</td><td>${esc(r.class)}</td><td>${r.score}</td><td>${r.stage}/50</td></tr>`).join('')+'</table>';
}

/* ===================== QUẢN TRỊ GIÁO VIÊN ===================== */
function renderTeacher(){applySettings();document.getElementById('teacherNameBadge').textContent=current?.name||'Giáo viên';renderTeacherStudents();renderTeacherAccounts();renderEventAdmin();renderQuestionTabs('math');renderSettings();renderOnlineClassesTeacher();renderOnlineExamsTeacher();renderStandardScores();}
function renderTeacherStudents(){
 const rows=getRankRows(),box=document.getElementById('teacherStudents');if(!box)return;
 box.innerHTML='<table><tr><th>Học sinh</th><th>Lớp</th><th>Điểm</th><th>Chặng</th><th>Quyền chỉnh sửa</th></tr>'+rows.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.class)}</td><td>${r.score}</td><td>${r.stage}/50</td><td><button class="btn mini" onclick="adjustScore('${r.u}',10)">+10</button> <button class="btn mini danger" onclick="adjustScore('${r.u}',-10)">−10</button> <button class="btn mini alt" onclick="setScore('${r.u}')">Sửa điểm</button> <button class="btn mini alt" onclick="editStudent('${r.u}')">Sửa HS</button> <button class="btn mini danger" onclick="resetStudent('${r.u}')">Reset</button></td></tr>`).join('')+'</table><button class="btn" onclick="addStudent()">+ Thêm học sinh</button>';
}
function adjustScore(u,n){if(!students[u])return;students[u].score=Math.max(0,Number(students[u].score||0)+n);saveDB();renderTeacherStudents();if(currentUsername===u)loadStudent();}
function setScore(u){if(!students[u])return;const v=prompt('Nhập điểm mới cho '+students[u].name,students[u].score);if(v!==null&&!isNaN(Number(v))){students[u].score=Math.max(0,Number(v));saveDB();renderTeacherStudents();if(currentUsername===u)loadStudent();}}
function editStudent(u){const s=students[u];if(!s)return;const name=prompt('Tên học sinh',s.name);if(name===null)return;const cls=prompt('Lớp',s.class);if(cls===null)return;const pass=prompt('Mật khẩu mới (bỏ trống để giữ nguyên)',s.pass);s.name=name.trim()||s.name;s.class=cls.trim()||s.class;if(pass!==null&&pass.trim())s.pass=pass.trim();saveDB();renderTeacherStudents();}
function addStudent(){const u=(prompt('Tài khoản mới, ví dụ: nguyen.van.a')||'').trim();if(!u||students[u]){if(u)alert('Tài khoản đã tồn tại.');return;}const name=(prompt('Họ và tên')||'').trim();if(!name)return;const cls=(prompt('Lớp','1A1')||'1A1').trim();const pass=(prompt('Mật khẩu','123456')||'123456').trim();students[u]={name,pass,class:cls,score:0,stage:0,completed:{}};saveDB();renderTeacherStudents();}
function resetStudent(u){if(!students[u]||!confirm('Reset điểm, chặng và tiến độ của '+students[u].name+'?'))return;students[u].score=0;students[u].stage=0;students[u].completed={};saveDB();renderTeacherStudents();if(currentUsername===u)loadStudent();}
function renderTeacherAccounts(){const box=document.getElementById('teacherAccounts');if(!box)return;box.innerHTML='<table><tr><th>Giáo viên</th><th>Tài khoản</th><th>Mật khẩu</th><th>Chỉnh sửa</th></tr>'+Object.entries(teachers).map(([u,t])=>`<tr><td>${esc(t.name)}</td><td>${esc(u)}</td><td>${esc(t.pass)}</td><td><button class="btn mini alt" onclick="editTeacher('${u}')">Sửa</button></td></tr>`).join('')+'</table>';}
function editTeacher(u){const t=teachers[u];if(!t)return;const name=prompt('Tên giáo viên',t.name);if(name===null)return;const pass=prompt('Mật khẩu',t.pass);if(pass===null)return;t.name=name.trim()||t.name;t.pass=pass.trim()||t.pass;saveDB();if(currentUsername===u)current.name=t.name;renderTeacherAccounts();document.getElementById('teacherNameBadge').textContent=current.name;}
function createEvent(){
 if(!current||current.role!=='teacher'){alert('Vui lòng đăng nhập bằng tài khoản giáo viên.');show('login');return;}
 const m=document.getElementById('createEventModal');if(!m){alert('Không tìm thấy cửa sổ Tạo sân chơi.');return;}
 const n=document.getElementById('eventNameInput'),d=document.getElementById('eventDescInput'),q=document.getElementById('eventQuestionsInput'),c=document.getElementById('eventRoundCountInput');
 if(n)n.value=''; if(d)d.value=''; if(q)q.value=''; if(c)c.value='3'; buildRoundInputs();
 m.classList.remove('hidden');m.style.display='flex';document.body.style.overflow='hidden';window.scrollTo({top:0,behavior:'smooth'});setTimeout(()=>n&&n.focus(),80);
}
function closeCreateEvent(){const m=document.getElementById('createEventModal');if(m){m.classList.add('hidden');m.style.display='none';}document.body.style.overflow='';}
function buildRoundInputs(){
 const box=document.getElementById('eventRoundInputs'); if(!box)return;
 const n=Math.max(1,Math.min(20,Number(document.getElementById('eventRoundCountInput')?.value)||1));
 let html='<h3 style="margin-top:14px">📅 Thời gian từng vòng</h3>';
 for(let i=1;i<=n;i++) html+=`<div class="card round-editor"><h4>Vòng ${i}</h4><div class="grid"><div><label>Từ ngày</label><input type="date" id="roundStart_${i}"></div><div><label>Đến ngày</label><input type="date" id="roundEnd_${i}"></div></div><p class="small">Học sinh chỉ được làm vòng ${i} trong khoảng thời gian này.</p></div>`;
 box.innerHTML=html;
}
function parseEventQuestions(raw){
 const out=[]; (raw||'').split(/\n+/).forEach(line=>{const p=line.split('|').map(x=>x.trim());if(p.length>=6){const correct='ABCD'.indexOf((p[5]||'').toUpperCase());if(correct>=0 && p[0] && p.slice(1,5).every(Boolean)){const points=Math.max(0,Number(p[6])||10);out.push({q:p[0],a:p.slice(1,5),correct,points,diff:30});}}}); return out;
}
function saveCreateEvent(){
 const name=(document.getElementById('eventNameInput').value||'').trim();
 const desc=(document.getElementById('eventDescInput').value||'').trim();
 const questions=parseEventQuestions(document.getElementById('eventQuestionsInput').value);
 const roundCount=Math.max(1,Math.min(20,Number(document.getElementById('eventRoundCountInput').value)||1));
 if(!name){alert('Anh hãy nhập tên sân chơi.');document.getElementById('eventNameInput').focus();return;}
 if(!questions.length){alert('Anh hãy nhập ít nhất 1 câu hỏi. Mỗi câu một dòng theo mẫu: Câu hỏi | A | B | C | D | A/B/C/D | Điểm');return;}
 const rounds=[];
 for(let i=1;i<=roundCount;i++){
   const start=document.getElementById('roundStart_'+i)?.value||'',end=document.getElementById('roundEnd_'+i)?.value||'';
   if(!start||!end){alert('Anh hãy nhập đủ ngày bắt đầu và ngày kết thúc cho Vòng '+i+'.');return;}
   if(start>end){alert('Vòng '+i+': ngày bắt đầu không được sau ngày kết thúc.');return;}
   if(i>1 && start<=rounds[i-2].end){alert('Vòng '+i+' phải bắt đầu sau khi Vòng '+(i-1)+' kết thúc.');return;}
   rounds.push({round:i,start,end});
 }
 const id='event_'+Date.now();
 db.events.push({id,name,desc:desc||'Sân chơi dành cho học sinh',open:false,createdBy:current?.name||'Giáo viên',createdAt:new Date().toISOString(),questions,rounds,roundCount});
 saveDB();closeCreateEvent();renderEventAdmin();renderHomeEvents();renderAllEvents();window.scrollTo({top:0,behavior:'smooth'});
 alert('🎉 Đã tạo sân chơi: '+name+'\n\n'+rounds.map(r=>'Vòng '+r.round+': '+r.start+' → '+r.end).join('\n'));
}
function toggleEvent(id){const e=db.events.find(x=>x.id===id);if(!e)return;e.open=!e.open;saveDB();renderEventAdmin();renderHomeEvents();renderAllEvents();}
function deleteEvent(id){if(!confirm('Xóa sân chơi này?'))return;db.events=db.events.filter(x=>x.id!==id);saveDB();renderEventAdmin();renderHomeEvents();}
function editEvent(id){const e=db.events.find(x=>x.id===id);if(!e)return;const name=prompt('Tên sân chơi',e.name);if(name===null)return;const desc=prompt('Mô tả',e.desc||'');if(desc===null)return;e.name=name.trim()||e.name;e.desc=desc;saveDB();renderEventAdmin();renderHomeEvents();}
function editEventQuestions(id){const e=db.events.find(x=>x.id===id);if(!e)return;const raw=prompt('Nhập câu hỏi mới, mỗi dòng: Câu hỏi | ĐA1 | ĐA2 | ĐA3 | ĐA4 | A/B/C/D | Điểm',e.questions.map(q=>q.q+' | '+q.a.join(' | ')+' | '+String.fromCharCode(65+q.correct)+' | '+Number(q.points??10)).join('\n'));if(raw===null)return;const out=parseEventQuestions(raw);if(out.length){e.questions=out;saveDB();renderEventAdmin();alert('Đã cập nhật câu hỏi của sân chơi.');}else alert('Không đọc được dữ liệu.');}
function renderEventAdmin(){const box=document.getElementById('eventAdmin');if(!box)return;let html='<div class="topbar"><div><span class="small">Quản lý toàn bộ sân chơi tại đây.</span></div><button class="btn" style="width:auto" onclick="createEvent()">➕ Tạo sân chơi mới</button></div>';if(!db.events.length){box.innerHTML=html+'<div class="notice">🎮 Chưa có sân chơi nào. Hãy bấm <b>+ Tạo sân chơi mới</b> để tạo.</div>';return;}box.innerHTML=html+db.events.map(e=>`<div class="card event"><div class="topbar"><div><h3>${esc(e.name)} ${e.open?'🟢 Đang mở':'🔒 Đang đóng'}</h3><p>${esc(e.desc||'')}</p><span class="small">${(e.questions||[]).length} câu hỏi • ${(e.rounds||[]).length||1} vòng • Người tạo: ${esc(e.createdBy||'')}</span></div><div><button class="btn mini" onclick="toggleEvent('${e.id}')">${e.open?'🔒 Đóng sân chơi':'🟢 Mở sân chơi'}</button><button class="btn mini alt" onclick="editEvent('${e.id}')">✏️ Sửa tên</button><button class="btn mini alt" onclick="editEventQuestions('${e.id}')">📝 Sửa câu hỏi</button><button class="btn mini danger" onclick="deleteEvent('${e.id}')">🗑 Xóa</button></div></div><div class="notice"><b>📅 Lịch vòng:</b> ${((e.rounds&&e.rounds.length)?e.rounds:[{round:1,start:'Không giới hạn',end:'Không giới hạn'}]).map(r=>`Vòng ${r.round}: ${r.start} → ${r.end}`).join(' • ')}</div></div>`).join('');}
function renderHomeEvents(){const box=document.getElementById('homeEvents');if(!box)return;const open=db.events.filter(e=>e.open);box.innerHTML=open.length?open.map(e=>`<div class="card event"><h3>🎉 ${esc(e.name)}</h3><p>${esc(e.desc||'Sân chơi đang mở.')}</p><button class="btn" onclick="startEvent('${e.id}')">Tham gia ngay</button></div>`).join(''):'<div class="notice">Hiện chưa có sân chơi nào được mở.</div>';}
function renderStudentEvents(){const box=document.getElementById('studentEvents');if(!box)return;const open=db.events.filter(e=>e.open);box.innerHTML=open.length?open.map(e=>`<div class="card event"><h3>🎉 ${esc(e.name)}</h3><p>${esc(e.desc||'')}</p><button class="btn" onclick="startEvent('${e.id}')">Vào sân chơi</button></div>`).join(''):'<div class="notice">Hiện chưa có sân chơi nào được mở.</div>';}
function renderTeacherEventsPage(){
 const box=document.getElementById('allEvents');
 if(!box)return;
 box.innerHTML=`<div class="notice"><b>👨‍🏫 Chế độ giáo viên:</b> Anh có thể tạo, mở, đóng và quản lý sân chơi ngay tại đây.</div><div class="event-actions"><button class="btn" onclick="createEvent()">➕ Tạo sân chơi mới</button><button class="btn alt" onclick="show('teacher')">⚙️ Quản lý chi tiết</button></div><div id="teacherEventsPage"></div>`;
 const list=document.getElementById('teacherEventsPage');
 if(!db.events.length){list.innerHTML='<div class="notice">🎮 Chưa có sân chơi. Bấm <b>➕ Tạo sân chơi mới</b> để bắt đầu.</div>';return;}
 list.innerHTML=db.events.map(e=>`<div class="card event"><h3>🎮 ${esc(e.name)} ${e.open?'🟢':'🔒'}</h3><p>${esc(e.desc||'Sân chơi dành cho học sinh')}</p><p class="small">${(e.questions||[]).length} câu hỏi • ${e.open?'Đang mở cho học sinh':'Đang đóng'}</p><button class="btn mini" onclick="toggleEvent('${e.id}');renderTeacherEventsPage()">${e.open?'🔒 Đóng':'🟢 Mở sân chơi'}</button> <button class="btn mini alt" onclick="editEvent('${e.id}')">✏️ Sửa tên</button> <button class="btn mini alt" onclick="editEventQuestions('${e.id}')">📝 Sửa câu hỏi</button> <button class="btn mini danger" onclick="deleteEvent('${e.id}');renderTeacherEventsPage()">🗑 Xóa</button></div>`).join('');
}

function renderAllEvents(){const box=document.getElementById('allEvents');if(!box)return;const open=db.events.filter(e=>e.open);box.innerHTML=open.length?open.map(e=>`<div class="card event"><h3>🎉 ${esc(e.name)}</h3><p>${esc(e.desc||'')}</p><button class="btn" onclick="startEvent('${e.id}')">Tham gia</button></div>`).join(''):'<div class="notice">Chưa có sân chơi nào được mở.';}
function startEvent(id){
 if(!current||current.role!=='student'){show('login');return;}
 const e=db.events.find(x=>x.id===id);if(!e||!e.open){alert('Sân chơi hiện đang đóng.');return;}
 const today=new Date().toISOString().slice(0,10);const rounds=(e.rounds&&e.rounds.length)?e.rounds:[{round:1,start:'1900-01-01',end:'2999-12-31'}];
 const activeRound=rounds.find(r=>today>=r.start&&today<=r.end);
 if(!activeRound){alert('⏰ Hiện không nằm trong thời gian của vòng nào trong sân chơi này. Hãy quay lại đúng ngày của từng vòng.');return;}
 const all=e.questions||[];currentQuestions=seededShuffle(all,hashCode(currentUsername+'|'+id+'|'+activeRound.round)).slice(0,all.length);currentStage='Vòng '+activeRound.round;currentPart=3;qIndex=0;show('stage');nextEventQuestion(e);
}
function nextEventQuestion(e){if(qIndex>=currentQuestions.length){alert('🎉 Hoàn thành '+e.name+'! Cộng 30 điểm.');current.score+=30;saveDB();loadStudent();return;}const q=currentQuestions[qIndex];document.getElementById('stageName').textContent=e.name+' • Câu '+(qIndex+1)+'/'+currentQuestions.length;document.getElementById('subjectName').textContent='🎮 Sân chơi sự kiện';document.getElementById('question').textContent=q.q;const a=document.getElementById('answers'),feedback=document.getElementById('answerFeedback');a.innerHTML='';if(feedback)feedback.innerHTML='';q.a.forEach((x,i)=>{const b=document.createElement('button');b.textContent=String.fromCharCode(65+i)+'. '+x;b.onclick=()=>eventAnswer(i===q.correct,i,q);a.appendChild(b);});seconds=q.diff||30;document.getElementById('timer').textContent=seconds+' giây';clearInterval(timerInt);timerInt=setInterval(()=>{seconds--;document.getElementById('timer').textContent=seconds+' giây';if(seconds<=0){clearInterval(timerInt);eventAnswer(false,-1,q,true);}},1000);}
function eventAnswer(correct,chosen,q,timeout=false){clearInterval(timerInt);document.querySelectorAll('#answers button').forEach((b,i)=>{b.disabled=true;if(i===q.correct)b.classList.add('correct-answer');if(i===chosen&&i!==q.correct)b.classList.add('wrong-answer');});if(correct){current.score+=Number(q.points??10);saveDB();}const f=document.getElementById('answerFeedback');if(f){f.className='answer-feedback '+(correct?'ok':'bad');f.innerHTML=(timeout?'⏰ Hết giờ. ':'')+(correct?'✅ Chính xác! +'+Number(q.points??10)+' điểm.':'❌ Chưa đúng. ')+'Đáp án đúng: '+String.fromCharCode(65+q.correct)+'. '+q.a[q.correct];}qIndex++;setTimeout(()=>nextEventQuestion(db.events.find(x=>x.name===document.getElementById('stageName').textContent.split(' • Câu ')[0])),1400);}

function renderQuestionTabs(active){const box=document.getElementById('questionTabs');const labels={math:'🔢 Toán',vietnamese:'📖 Tiếng Việt',science:'🌱 Khoa học',english:'🇬🇧 Tiếng Anh',challenge:'⚡ Đua sức'};box.innerHTML=Object.entries(labels).map(([k,v])=>`<button class="${k===active?'active':''}" onclick="renderQuestionTabs('${k}')">${v}</button>`).join('');renderQuestionEditor(active);}
function bankForEdit(key){if(!db.customBanks[key])db.customBanks[key]=JSON.parse(JSON.stringify(questionBank[key]));return db.customBanks[key];}
function renderQuestionEditor(key){const box=document.getElementById('questionEditor');const bank=bankForEdit(key);box.innerHTML='<div class="notice">Giáo viên có thể sửa <b>cả câu hỏi, tất cả đáp án, đáp án đúng, thời gian và điểm</b>. Lưu xong học sinh sẽ dùng dữ liệu mới.</div>'+bank.map((q,i)=>`<div class="card edit-question"><label>Câu ${i+1}</label><input id="q_${key}_${i}" value="${esc(q.q)}"><label>Đáp án A</label><input id="a_${key}_${i}_0" value="${esc(q.a[0]||'')}"><label>Đáp án B</label><input id="a_${key}_${i}_1" value="${esc(q.a[1]||'')}"><label>Đáp án C</label><input id="a_${key}_${i}_2" value="${esc(q.a[2]||'')}"><label>Đáp án D</label><input id="a_${key}_${i}_3" value="${esc(q.a[3]||'')}"><label>Đáp án đúng</label><select id="c_${key}_${i}">${q.a.map((x,j)=>`<option value="${j}" ${j===q.correct?'selected':''}>${String.fromCharCode(65+j)} - ${esc(x)}</option>`).join('')}</select><label>Điểm câu</label><input type="number" id="p_${key}_${i}" value="${Number(q.points??10)}"><label>Thời gian (giây)</label><input type="number" id="t_${key}_${i}" value="${Number(q.diff??(key==='challenge'?30:20))}"><button class="btn mini" onclick="saveQuestion('${key}',${i})">💾 Lưu câu</button> <button class="btn mini danger" onclick="deleteQuestion('${key}',${i})">🗑 Xóa câu</button></div>`).join('')+'<button class="btn" onclick="addQuestion(\''+key+'\')">+ Thêm câu hỏi</button>';}
function saveQuestion(key,i){const bank=bankForEdit(key),q=document.getElementById(`q_${key}_${i}`).value.trim(),a=[0,1,2,3].map(j=>document.getElementById(`a_${key}_${i}_${j}`).value.trim()),c=Number(document.getElementById(`c_${key}_${i}`).value),points=Math.max(0,Number(document.getElementById(`p_${key}_${i}`).value)||0),diff=Math.max(5,Number(document.getElementById(`t_${key}_${i}`).value)||20);if(!q||a.some(x=>!x)||c<0||c>3){alert('Hãy nhập đủ câu hỏi, 4 đáp án và đáp án đúng.');return;}bank[i]={...bank[i],q,a,correct:c,points,diff};saveDB();renderQuestionEditor(key);alert('Đã lưu câu hỏi và đáp án.');}
function deleteQuestion(key,i){if(!confirm('Xóa câu hỏi này?'))return;bankForEdit(key).splice(i,1);saveDB();renderQuestionEditor(key);}
function addQuestion(key){const bank=bankForEdit(key);bank.push({q:'Câu hỏi mới',a:['Đáp án A','Đáp án B','Đáp án C','Đáp án D'],correct:0,points:10,diff:key==='challenge'?30:20});saveDB();renderQuestionEditor(key);}

function renderSettings(){const box=document.getElementById('settingsEditor');if(!box)return;const s=db.settings;box.innerHTML=`<div class="grid"><div><label>Tên app</label><input id="setAppName" value="${esc(s.appName)}"></div><div><label>Tên trường</label><input id="setSchoolName" value="${esc(s.schoolName)}"></div><div><label>Khẩu hiệu</label><input id="setTagline" value="${esc(s.tagline)}"></div></div><label>Ảnh/logo app</label><input type="file" id="logoFile" accept="image/*"><button class="btn" onclick="saveSettings()">💾 Lưu giao diện</button><button class="btn alt" onclick="exportDatabase()">⬇️ Sao lưu cơ sở dữ liệu</button><label>Khôi phục cơ sở dữ liệu</label><input type="file" id="dbFile" accept="application/json"><button class="btn alt" onclick="importDatabase()">⬆️ Khôi phục dữ liệu</button>`;}
function saveSettings(){db.settings.appName=document.getElementById('setAppName').value.trim()||defaultSettings.appName;db.settings.schoolName=document.getElementById('setSchoolName').value.trim()||defaultSettings.schoolName;db.settings.tagline=document.getElementById('setTagline').value.trim()||defaultSettings.tagline;const f=document.getElementById('logoFile').files[0];if(f){const r=new FileReader();r.onload=()=>{db.settings.logo=r.result;saveDB();applySettings();renderSettings();alert('Đã cập nhật giao diện và logo.');};r.readAsDataURL(f);}else{saveDB();applySettings();alert('Đã cập nhật giao diện.');}}
function exportDatabase(){const blob=new Blob([JSON.stringify(db,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='CSDL_Dau_Truong_An_Quang_So_1.json';a.click();URL.revokeObjectURL(a.href);}
function importDatabase(){const f=document.getElementById('dbFile').files[0];if(!f)return alert('Chọn file CSDL trước.');const r=new FileReader();r.onload=()=>{try{const x=JSON.parse(r.result);if(!x.students||!x.teachers)throw Error();db=x;students=db.students;teachers=db.teachers;saveDB();applySettings();renderTeacher();alert('Đã khôi phục cơ sở dữ liệu.');}catch(e){alert('File CSDL không hợp lệ.');}};r.readAsText(f);}
function renderTeacher(){applySettings();document.getElementById('teacherNameBadge').textContent=current?.name||'Giáo viên';renderTeacherStudents();renderTeacherAccounts();renderEventAdmin();renderQuestionTabs('math');renderSettings();renderOnlineClassesTeacher();renderOnlineExamsTeacher();renderStandardScores();}
function esc(x){return String(x??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function logout(){current=null;currentUsername=null;clearInterval(timerInt);show('home');}
applySettings();show('home');renderHomeEvents();


/* ===================== HỌC ONLINE & THI ONLINE ===================== */
let activeExam=null, examIndex=0, examAnswers={}, examTimerInt=null, examSeconds=0;
function createOnlineClass(){
 if(!current||current.role!=='teacher')return show('login');
 const name=prompt('Tên lớp học online:','Lớp học Toán'); if(!name)return;
 const lesson=prompt('Nội dung bài học:','Ôn tập bài hôm nay'); if(lesson===null)return;
 const code=makeCode('AQ'); db.onlineClasses.push({id:'oc_'+Date.now(),name,lesson,code,teacher:current.name,open:true,chat:[]});saveDB();renderOnlineClassesTeacher();alert('Đã tạo lớp. Mã vào lớp: '+code);
}
function openTeacherOnlineClasses(){renderOnlineClassesTeacher();document.getElementById('teacherOnlineClasses')?.scrollIntoView({behavior:'smooth'});}
function renderOnlineClassesTeacher(){const box=document.getElementById('teacherOnlineClasses');if(!box)return;box.innerHTML=db.onlineClasses.length?db.onlineClasses.map(c=>`<div class="card"><h3>📹 ${esc(c.name)} ${c.open?'🟢':'🔒'}</h3><p>${esc(c.lesson)}</p><p><b>Mã lớp: ${esc(c.code)}</b> • Giáo viên: ${esc(c.teacher)}</p><button class="btn mini" onclick="toggleOnlineClass('${c.id}')">${c.open?'🔒 Đóng lớp':'🟢 Mở lớp'}</button> <button class="btn mini alt" onclick="editOnlineClass('${c.id}')">✏️ Sửa</button></div>`).join(''):'<div class="notice">Chưa có lớp học online.</div>';}
function toggleOnlineClass(id){const c=db.onlineClasses.find(x=>x.id===id);if(c){c.open=!c.open;saveDB();renderOnlineClassesTeacher();}}
function editOnlineClass(id){const c=db.onlineClasses.find(x=>x.id===id);if(!c)return;const lesson=prompt('Nội dung bài học:',c.lesson);if(lesson!==null){c.lesson=lesson;saveDB();renderOnlineClassesTeacher();}}
function renderOnlineClasses(){const box=document.getElementById('onlineClassList');if(!box)return;const open=db.onlineClasses.filter(c=>c.open);box.innerHTML=open.length?open.map(c=>`<div class="notice"><b>${esc(c.name)}</b><br>${esc(c.lesson)}<br><span class="small">Giáo viên: ${esc(c.teacher)} • Mã: ${esc(c.code)}</span></div>`).join(''):'<div class="small">Chưa có phòng học đang mở.</div>';}
function joinOnlineClass(){const code=(document.getElementById('classCodeInput').value||'').trim().toUpperCase();const c=db.onlineClasses.find(x=>x.code===code&&x.open);if(!c)return alert('Mã lớp không đúng hoặc phòng đã đóng.');current.onlineClassId=c.id;saveDB();openOnlineRoom(c.id);}
function openOnlineRoom(id){const c=db.onlineClasses.find(x=>x.id===id);if(!c)return;document.getElementById('onlineRoomTitle').textContent='📹 '+c.name+' • '+c.code;document.getElementById('onlineLessonContent').innerHTML='<p>'+esc(c.lesson)+'</p><p class="small">Giáo viên: '+esc(c.teacher)+'</p>';document.getElementById('onlineChat').innerHTML=(c.chat||[]).map(m=>`<div class="notice"><b>${esc(m.user)}:</b> ${esc(m.text)}</div>`).join('');show('onlineClassRoom');}
function sendOnlineChat(){const input=document.getElementById('onlineChatInput');if(!input||!input.value.trim())return;const c=db.onlineClasses.find(x=>x.id===current?.onlineClassId);if(!c)return;c.chat=c.chat||[];c.chat.push({user:current.name,text:input.value.trim()});input.value='';saveDB();openOnlineRoom(c.id);}
async function startCamera(){const v=document.getElementById('teacherCamera');if(!navigator.mediaDevices?.getUserMedia)return alert('Trình duyệt này không hỗ trợ camera.');try{const stream=await navigator.mediaDevices.getUserMedia({video:true,audio:false});v.srcObject=stream;}catch(e){alert('Hãy cấp quyền camera cho trình duyệt để bật camera.');}}
function createOnlineExam(){
 if(!current||current.role!=='teacher')return show('login');
 const name=prompt('Tên đề thi online:','Bài kiểm tra Toán');if(!name)return;
 const duration=Math.max(1,Number(prompt('Thời gian làm bài (phút):','30'))||30);
 const raw=prompt('Nhập câu hỏi, mỗi dòng theo mẫu: Câu hỏi | A | B | C | D | Đáp án đúng | Điểm\nCó thể thêm dạng NỐI sau này bằng cách giáo viên cập nhật trong dữ liệu.');if(!raw)return;
 const questions=raw.split(/\n+/).map(line=>{const p=line.split('|').map(x=>x.trim());if(p.length<7)return null;const correct=Math.max(0,Math.min(3,'ABCD'.indexOf((p[5]||'A').toUpperCase())));return {q:p[0],a:p.slice(1,5),correct,points:Number(p[6])||1,type:'choice'};}).filter(Boolean);
 if(!questions.length)return alert('Chưa có câu hỏi hợp lệ.');
 const exam={id:'ex_'+Date.now(),name,duration,code:makeCode('EX'),questions,open:false,teacher:current.name,results:{},createdAt:new Date().toISOString()};db.onlineExams.push(exam);saveDB();renderOnlineExamsTeacher();alert('Đã tạo đề. Mã đề: '+exam.code+'\nHãy gửi mã này cho học sinh.');
}
function renderOnlineExamsTeacher(){const box=document.getElementById('teacherOnlineExams');if(!box)return;box.innerHTML=db.onlineExams.length?db.onlineExams.map(e=>`<div class="card"><h3>📝 ${esc(e.name)} ${e.open?'🟢':'🔒'}</h3><p><b>Mã đề: ${esc(e.code)}</b> • ${(e.questions||[]).length} câu • ${e.duration} phút</p><p class="small">${e.open?'Đang cho học sinh làm':'Chưa mở'}</p><button class="btn mini" onclick="toggleOnlineExam('${e.id}')">${e.open?'🔒 Đóng đề':'🟢 Mở đề'}</button> <button class="btn mini alt" onclick="editOnlineExam('${e.id}')">✏️ Cập nhật câu hỏi</button> <button class="btn mini alt" onclick="viewExamResults('${e.id}')">📊 Kết quả</button></div>`).join(''):'<div class="notice">Chưa có đề thi online.</div>';}
function toggleOnlineExam(id){const e=db.onlineExams.find(x=>x.id===id);if(e){e.open=!e.open;saveDB();renderOnlineExamsTeacher();}}
function editOnlineExam(id){const e=db.onlineExams.find(x=>x.id===id);if(!e)return;const raw=prompt('Cập nhật toàn bộ câu hỏi theo mẫu: Câu hỏi | A | B | C | D | A/B/C/D | Điểm',e.questions.map(q=>`${q.q} | ${q.a.join(' | ')} | ${String.fromCharCode(65+q.correct)} | ${q.points}`).join('\n'));if(raw===null)return;const qs=raw.split(/\n+/).map(line=>{const p=line.split('|').map(x=>x.trim());if(p.length<7)return null;return {q:p[0],a:p.slice(1,5),correct:Math.max(0,Math.min(3,'ABCD'.indexOf((p[5]||'A').toUpperCase()))),points:Number(p[6])||1,type:'choice'};}).filter(Boolean);if(qs.length){e.questions=qs;saveDB();renderOnlineExamsTeacher();alert('Đã cập nhật đề thi.');}}
function joinOnlineExam(){const code=(document.getElementById('examCodeInput').value||'').trim().toUpperCase();const e=db.onlineExams.find(x=>x.code===code&&x.open);if(!e)return alert('Mã đề không đúng hoặc đề chưa được mở.');if(e.results?.[currentUsername])return alert('Bạn đã nộp bài này rồi.');activeExam=e;examIndex=0;examAnswers={};examSeconds=e.duration*60;show('onlineExamRoom');renderExamQuestion();clearInterval(examTimerInt);examTimerInt=setInterval(()=>{examSeconds--;document.getElementById('examTimer').textContent=Math.floor(examSeconds/60)+' phút '+(examSeconds%60)+' giây';if(examSeconds<=0)submitOnlineExam(true);},1000);}
function renderExamQuestion(){const e=activeExam,q=e.questions[examIndex];document.getElementById('onlineExamTitle').textContent='📝 '+e.name+' • Câu '+(examIndex+1)+'/'+e.questions.length;document.getElementById('examQuestion').innerHTML=`<div class="question">${esc(q.q)}</div>`;const box=document.getElementById('examAnswers');box.innerHTML=q.a.map((a,i)=>`<button class="answers" style="display:block;width:100%;margin:7px 0;padding:14px;border:1px solid #ddd;border-radius:12px;background:white;text-align:left;cursor:pointer" onclick="chooseExamAnswer(${i})">${String.fromCharCode(65+i)}. ${esc(a)}</button>`).join('');document.getElementById('examTimer').textContent=Math.floor(examSeconds/60)+' phút '+(examSeconds%60)+' giây';}
function chooseExamAnswer(i){examAnswers[examIndex]=i;if(examIndex<activeExam.questions.length-1){examIndex++;renderExamQuestion();}else{document.getElementById('examSubmitBtn').textContent='Nộp bài';}}
function submitOnlineExam(timeout=false){if(!activeExam)return;clearInterval(examTimerInt);let points=0,max=0,correct=0;activeExam.questions.forEach((q,i)=>{max+=Number(q.points)||1;if(examAnswers[i]===q.correct){points+=Number(q.points)||1;correct++;}});const score=max?Math.round(points/max*10*10)/10:0;activeExam.results=activeExam.results||{};activeExam.results[currentUsername]={name:current.name,class:current.class,score,correct,total:activeExam.questions.length,submittedAt:new Date().toISOString(),timeout};current.onlineExamScore=score;current.standardScore=((Number(current.schoolExamScore)||0)+score)/2;current.examResults=current.examResults||{};current.examResults[activeExam.id]=activeExam.results[currentUsername];saveDB();alert((timeout?'⏰ Hết giờ. ':'')+'Đã nộp bài! Điểm thi online: '+score+'\nĐiểm chuẩn = ('+(Number(current.schoolExamScore)||0)+' + '+score+') ÷ 2 = '+current.standardScore);activeExam=null;loadStudent();}
function renderStudentExamResult(){const box=document.getElementById('studentExamResult');if(!box||!current)return;const rows=Object.entries(current.examResults||{}).map(([id,r])=>{const e=db.onlineExams.find(x=>x.id===id);return `<div class="notice"><b>${esc(e?.name||'Đề thi')}</b>: ${r.score}/10 • ${r.correct}/${r.total} câu</div>`});box.innerHTML=rows.join('')||'<span class="small">Chưa có kết quả thi online.</span>';}
function viewExamResults(id){const e=db.onlineExams.find(x=>x.id===id);if(!e)return;const rows=Object.values(e.results||{});alert(rows.length?rows.map(r=>`${r.name} (${r.class}): ${r.score}/10 • ${r.correct}/${r.total} câu`).join('\n'):'Chưa có học sinh nộp bài.');}
function renderStandardScores(){const box=document.getElementById('teacherStandardScores');if(!box)return;box.innerHTML=`<table><tr><th>Học sinh</th><th>Lớp</th><th>Thi trên trường</th><th>Thi online</th><th>Điểm chuẩn</th><th>Thao tác</th></tr>${Object.values(db.students).map(st=>`<tr><td>${esc(st.name)}</td><td>${esc(st.class)}</td><td><input type="number" min="0" max="10" step="0.1" value="${Number(st.schoolExamScore)||0}" onchange="setSchoolExamScore('${Object.keys(db.students).find(k=>db.students[k]===st)}',this.value)"></td><td>${Number(st.onlineExamScore||0).toFixed(1)}</td><td><b>${(((Number(st.schoolExamScore)||0)+(Number(st.onlineExamScore)||0))/2).toFixed(1)}</b></td><td><button class="btn mini" onclick="setSchoolExamScorePrompt('${Object.keys(db.students).find(k=>db.students[k]===st)}')">Cập nhật</button></td></tr>`).join('')}</table>`;}
function setSchoolExamScore(u,v){const st=db.students[u];if(!st)return;st.schoolExamScore=Math.max(0,Math.min(10,Number(v)||0));st.standardScore=(st.schoolExamScore+(Number(st.onlineExamScore)||0))/2;saveDB();renderStandardScores();if(currentUsername===u){current=st;loadStudent();}}
function setSchoolExamScorePrompt(u){const st=db.students[u];if(!st)return;const v=prompt('Điểm thi trên trường (0-10):',Number(st.schoolExamScore)||0);if(v!==null)setSchoolExamScore(u,v);}
